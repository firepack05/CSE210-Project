using System;

class Entry
{
    private string _date;
    private string _prompt;
    private string _response;
    private string _mood;

    public Entry(string date, string prompt, string response, string mood)
    {
        _date = date;
        _prompt = prompt;
        _response = response;
        _mood = mood;
    }

    public string GetDate()
    {
        return _date;
    }

    public string GetPrompt()
    {
        return _prompt;
    }

    public string GetResponse()
    {
        return _response;
    }

    public string GetMood()
    {
        return _mood;
    }

    public void Display()
    {
        Console.WriteLine($"Date: {_date}");
        Console.WriteLine($"Prompt: {_prompt}");
        Console.WriteLine($"Response: {_response}");
        Console.WriteLine($"Mood: {_mood}");
        Console.WriteLine();
    }

    public string ToFileString()
    {
        // Replace the separator inside user text so each entry can be loaded safely.
        return $"{Clean(_date)}~|~{Clean(_prompt)}~|~{Clean(_response)}~|~{Clean(_mood)}";
    }

    private string Clean(string value)
    {
        return value.Replace("~|~", " ");
    }

    public static Entry FromFileString(string line)
    {
        string[] parts = line.Split(new string[] { "~|~" }, StringSplitOptions.None);
        if (parts.Length < 4)
        {
            throw new FormatException("This line is not a valid journal entry.");
        }

        return new Entry(parts[0], parts[1], parts[2], parts[3]);
    }
}
