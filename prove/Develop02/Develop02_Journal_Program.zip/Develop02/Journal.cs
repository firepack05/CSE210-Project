using System;
using System.Collections.Generic;
using System.IO;

class Journal
{
    private List<Entry> _entries = new List<Entry>();

    public void AddEntry(Entry entry)
    {
        _entries.Add(entry);
    }

    public void Display()
    {
        if (_entries.Count == 0)
        {
            Console.WriteLine("Your journal is empty.");
            return;
        }

        foreach (Entry entry in _entries)
        {
            entry.Display();
        }
    }

    public void SaveToFile(string filename)
    {
        if (string.IsNullOrWhiteSpace(filename))
        {
            Console.WriteLine("Filename cannot be empty.");
            return;
        }

        try
        {
            using (StreamWriter outputFile = new StreamWriter(filename))
            {
                foreach (Entry entry in _entries)
                {
                    outputFile.WriteLine(entry.ToFileString());
                }
            }

            Console.WriteLine("Journal saved successfully.");
        }
        catch (Exception)
        {
            Console.WriteLine("The journal could not be saved. Check the filename and try again.");
        }
    }

    public void LoadFromFile(string filename)
    {
        if (string.IsNullOrWhiteSpace(filename))
        {
            Console.WriteLine("Filename cannot be empty.");
            return;
        }

        try
        {
            string[] lines = File.ReadAllLines(filename);
            List<Entry> loadedEntries = new List<Entry>();

            foreach (string line in lines)
            {
                if (!string.IsNullOrWhiteSpace(line))
                {
                    loadedEntries.Add(Entry.FromFileString(line));
                }
            }

            // Replace current entries only after the file has been read successfully.
            _entries = loadedEntries;
            Console.WriteLine("Journal loaded successfully.");
        }
        catch (Exception)
        {
            Console.WriteLine("The journal could not be loaded. Check that the file exists and try again.");
        }
    }
}
