CSE 210 - Develop02 Journal Program

Files:
- Program.cs: menu and program flow
- Entry.cs: stores and displays one journal entry
- Journal.cs: manages entries and saves/loads them

Features:
- Random writing prompts
- Date, prompt, response, and mood stored for each entry
- Display all entries
- Save entries to a text file
- Load entries from a text file, replacing the current journal
- Extra feature: mood tracking

How to use:
1. Open this folder as your Develop02 project in VS Code, or copy the three .cs files into your existing course repository's Prove/Develop02 folder.
2. Run the project with `dotnet run`.
3. Use menu options 1-5.
4. When saving, use a filename such as journal.txt. The file is saved relative to the program's working directory.

Important:
Submit the link to your own GitHub repository after committing and pushing these files. A downloadable ZIP by itself is not the GitHub submission link.
