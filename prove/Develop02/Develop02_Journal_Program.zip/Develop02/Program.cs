using System;
using System.Collections.Generic;

// Creativity beyond the core requirements:
// Each entry also stores a mood. This lets users look back at how they felt
// on a particular day, in addition to reading their prompt and response.

class Program
{
    static void Main(string[] args)
    {
        Journal journal = new Journal();
        List<string> prompts = new List<string>
        {
            "What was the best part of my day?",
            "What is something new I learned today?",
            "Who helped me today, and how?",
            "What is one thing I could improve tomorrow?",
            "How did I see the hand of the Lord in my life today?",
            "What is something I am grateful for?"
        };

        bool running = true;

        while (running)
        {
            Console.WriteLine();
            Console.WriteLine("Welcome to the Journal Program!");
            Console.WriteLine("Please select one of the following choices:");
            Console.WriteLine("1. Write");
            Console.WriteLine("2. Display");
            Console.WriteLine("3. Load");
            Console.WriteLine("4. Save");
            Console.WriteLine("5. Quit");
            Console.Write("What would you like to do? ");

            string choice = Console.ReadLine() ?? "";

            switch (choice)
            {
                case "1":
                    Random random = new Random();
                    string prompt = prompts[random.Next(prompts.Count)];
                    Console.WriteLine(prompt);
                    Console.Write("Response: ");
                    string response = Console.ReadLine() ?? "";
                    Console.Write("How were you feeling today? ");
                    string mood = Console.ReadLine() ?? "";
                    string date = DateTime.Now.ToShortDateString();

                    Entry entry = new Entry(date, prompt, response, mood);
                    journal.AddEntry(entry);
                    Console.WriteLine("Your entry has been added.");
                    break;

                case "2":
                    journal.Display();
                    break;

                case "3":
                    Console.Write("Enter the filename to load: ");
                    string loadFile = Console.ReadLine() ?? "";
                    journal.LoadFromFile(loadFile);
                    break;

                case "4":
                    Console.Write("Enter the filename to save: ");
                    string saveFile = Console.ReadLine() ?? "";
                    journal.SaveToFile(saveFile);
                    break;

                case "5":
                    running = false;
                    break;

                default:
                    Console.WriteLine("Please enter a number from 1 to 5.");
                    break;
            }
        }
    }
}
